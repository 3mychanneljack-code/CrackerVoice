package com.example.voiceassistant.notify

import android.app.Notification
import android.app.Person
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Captures message notifications and speaks them. The latest one is the
 * reply target until the user answers it or a newer message arrives.
 */
class MessageNotificationListener : NotificationListenerService() {

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (utteranceId == REPLY_UTTERANCE) {
                            sendBroadcast(
                                Intent(ACTION_REPLY_LISTEN).setPackage(packageName)
                            )
                        }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {}
                })
            }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onListenerConnected() {
        instance = this
        activeNotifications?.forEach { record(it, speak = false) }
    }

    override fun onListenerDisconnected() {
        if (instance == this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        record(sbn, speak = true)
    }

    private fun record(sbn: StatusBarNotification, speak: Boolean) {
        if (!isMessageNotification(sbn)) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val lines = messagingLines(extras)
        val fallback = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        val body = when {
            lines.isNotEmpty() -> lines.joinToString(" | ")
            !fallback.isNullOrBlank() -> fallback.trim()
            else -> return
        }
        val who = title.ifBlank { "Someone" }
        val entry = Entry(
            System.currentTimeMillis(),
            who,
            body,
            sbn.packageName,
            phoneFrom(extras)
        )
        synchronized(lock) {
            recent.add(0, entry)
            while (recent.size > MAX) recent.removeAt(recent.lastIndex)
            replyTarget = entry
            awaitingReply = true
        }
        if (speak && ttsReady) {
            tts?.speak(
                "Message from $who. $body. Say your reply.",
                TextToSpeech.QUEUE_FLUSH,
                null,
                REPLY_UTTERANCE
            )
        }
    }

    private fun isMessageNotification(sbn: StatusBarNotification): Boolean {
        val category = sbn.notification.category
        if (category == Notification.CATEGORY_MESSAGE) return true
        val pkg = sbn.packageName
        return pkg == "com.google.android.apps.messaging" ||
            pkg == "com.samsung.android.messaging" ||
            pkg.endsWith(".messaging") ||
            pkg.contains("mms") ||
            pkg.contains("sms")
    }

    private fun messagingLines(extras: Bundle): List<String> {
        val parcels = extras.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return emptyList()
        return parcels.mapNotNull { item ->
            val bundle = item as? Bundle ?: return@mapNotNull null
            val text = bundle.getCharSequence("text")?.toString()?.trim().orEmpty()
            if (text.isEmpty()) return@mapNotNull null
            val sender = bundle.getCharSequence("sender")?.toString()?.trim().orEmpty()
            if (sender.isEmpty()) text else "$sender: $text"
        }
    }

    private fun phoneFrom(extras: Bundle): String? {
        if (Build.VERSION.SDK_INT < 28) return null
        val parcels = extras.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return null
        for (item in parcels) {
            val bundle = item as? Bundle ?: continue
            val person = bundle.getParcelable<Person>("sender_person")
            val uri = person?.uri ?: continue
            if (uri.startsWith("tel:")) return uri.removePrefix("tel:")
        }
        return null
    }

    data class Entry(
        val timeMillis: Long,
        val title: String,
        val body: String,
        val packageName: String,
        val number: String?
    )

    companion object {
        const val ACTION_REPLY_LISTEN = "com.example.voiceassistant.REPLY_LISTEN"
        private const val REPLY_UTTERANCE = "incoming-message"
        private const val MAX = 40
        private val lock = Any()
        private val recent = ArrayDeque<Entry>()
        @Volatile
        private var instance: MessageNotificationListener? = null
        @Volatile
        private var replyTarget: Entry? = null
        @Volatile
        private var awaitingReply = false

        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            val component = ComponentName(context, MessageNotificationListener::class.java)
            return flat.contains(component.flattenToString()) || flat.contains(context.packageName)
        }

        fun isAwaitingReply(): Boolean = awaitingReply

        fun replyTarget(): Entry? = replyTarget

        fun markNewestAsReplyTarget() {
            synchronized(lock) {
                val newest = recent.firstOrNull() ?: return
                replyTarget = newest
                awaitingReply = true
            }
        }

        fun clearAwaitingReply() {
            awaitingReply = false
        }

        fun recentText(limit: Int): String {
            val snapshot = synchronized(lock) { recent.take(limit) }
            if (snapshot.isEmpty()) {
                return if (instance == null) {
                    "No message notifications yet. Turn on notification access for this app, then ask again after a message arrives."
                } else {
                    "Notification access is on, but no message notifications have arrived since it was enabled."
                }
            }
            return snapshot.joinToString("\n") { entry ->
                val number = entry.number?.let { " ($it)" }.orEmpty()
                "${entry.title}$number: ${entry.body}"
            }
        }
    }
}
